
USE [FactSales]
GO

CREATE FUNCTION dbo.SplitStrings
(
   @List       NVARCHAR(MAX),
   @Delimiter  NVARCHAR(255)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
   RETURN 
   (  
      SELECT Item = y.i.value('(./text())[1]', 'nvarchar(4000)')
      FROM 
      ( 
        SELECT x = CONVERT(XML, '<i>' 
          + REPLACE(@List, @Delimiter, '</i><i>') 
          + '</i>').query('.')
      ) AS a CROSS APPLY x.nodes('i') AS y(i)
   );
GO

USE [FactSales]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC getSalesYTD ( @TerritoryID INT, @SalesPersons nvarchar(max))
as 
BEGIN
select 
fact.TerritoryID as TerritoryID,
person.Title as [Job Title],
Person.FirstName As [Sales Person Firstname]
person.LastName As [Sales Person Lastname]
SUM(fact.salesYTD) as [Sales YTD]
from FactSales fact,
	DimSalesOrderDetail dimdetail,
	DimPerson person,
	DimDate period
	where fact.TerritoryID = @TerritoryID
	AND (Person.FirstName+' '+person.LastName) IN (select * from dbo.SplitStrings(@SalesPersons,',')

END


Bonus:
---Get Percent of Total per employee.
;WITH 
    one AS (
        SELECT SUM(SalesAmount) AS Grand_Tot_Sales
        FROM dbo.FactSales
    ),
    two AS (
       SELECT BusinessEntityID , 
        SUM(SalesAmount) AS Total_Sales , 
        SUM(TotalProductCost) AS Total_cost
       FROM dbo.FactSales
       GROUP BY BusinessEntityID
)

SELECT 
    Total_Sales / Grand_Tot_Sales * 100 AS Prct_of_Total   
FROM one, two


----Get employee rank by sales.

select distinct
    OrderDate, SalesPersonID, Employee
from
    (
    select
        SOH.SalesOrderID, 
        SOH.OrderDate,
        SOH.SalesPersonID, 
        SP.FirstName + ' ' + SP.LastName Employee,
        rank() over(Partition by SOH.SalesPersonID order by OrderDate desc) OrderRank
    from 
        SalesOrderheader SOH
        inner join SalesPerson SP on SOH.SalesPersonID = SP.SalesPersonID
        
    ) RankedOrders
where
    RankedOrders.OrderRank = 1