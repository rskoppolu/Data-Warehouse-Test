
USE [FactSales]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC usp_getSalesQty 
AS
BEGIN
select dimdetail.ProductID As PrductID,
SUM(fact.OrderQty) AS [Order Quantity],
fact.SalesorderID AS SalesorderID,
Person.FirstName As [Sales Person Firstname]
person.LastName As [Sales Person Lastname]
fact.OrderDate As [Order Date]
fact.TerritoryID as TerritoryID
from FactSales fact,
	DimSalesOrderDetail dimdetail,
	DimPerson person,
	DimDate period
GROUP BY 
	dimdetail.ProductID,
	fact.SalesorderID,
	Person.FirstName,
	person.LastName,
	fact.OrderDate,
	fact.TerritoryID ;
END;


